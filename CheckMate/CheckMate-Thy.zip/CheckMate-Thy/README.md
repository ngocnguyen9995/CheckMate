# CheckMate
Setting up repo.
MainController & Menu Commit
