import java.util.*;
import java.net.*;
import java.io.*;

public class TestHost {

    public static void main(String[] args) {
        System.out.println("Init Host");
        Host host = new Host();
        System.out.println("Start game");
        host.playGame();
    }

}
